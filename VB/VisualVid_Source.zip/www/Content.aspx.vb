
Partial Class Content
    Inherits System.Web.UI.Page
End Class
