
Partial Class _CMS_PortalHeader
    Inherits System.Web.UI.Page

End Class
