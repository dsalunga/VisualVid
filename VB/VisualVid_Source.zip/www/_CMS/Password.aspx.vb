
Partial Class _CMS_Password
    Inherits System.Web.UI.Page

End Class
