
Partial Class _CMS_MasterPage
    Inherits System.Web.UI.MasterPage
End Class

