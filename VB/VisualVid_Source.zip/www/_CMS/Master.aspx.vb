
Partial Class _CMS_Master
    Inherits System.Web.UI.Page

End Class
