
Partial Class Member_UserNavigation
    Inherits System.Web.UI.UserControl

End Class
