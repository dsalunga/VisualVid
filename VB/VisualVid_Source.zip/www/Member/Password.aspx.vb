
Partial Class Member_Password
    Inherits System.Web.UI.Page

End Class
