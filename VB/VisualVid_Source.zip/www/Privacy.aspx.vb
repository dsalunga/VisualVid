
Partial Class Privacy
    Inherits System.Web.UI.Page

End Class
