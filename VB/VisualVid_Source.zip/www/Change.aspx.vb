
Partial Class Change
    Inherits System.Web.UI.Page

End Class
