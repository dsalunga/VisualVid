
Partial Class Terms
    Inherits System.Web.UI.Page

End Class
