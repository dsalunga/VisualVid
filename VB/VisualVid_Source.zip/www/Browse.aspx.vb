
Partial Class Browse
    Inherits System.Web.UI.Page

End Class
