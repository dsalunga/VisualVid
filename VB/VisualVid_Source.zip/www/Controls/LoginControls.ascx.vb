
Partial Class Controls_LoginControls
    Inherits System.Web.UI.UserControl

End Class
