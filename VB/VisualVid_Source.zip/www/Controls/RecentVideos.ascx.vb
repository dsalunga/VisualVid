
Partial Class Controls_RecentVideos
    Inherits System.Web.UI.UserControl

End Class
