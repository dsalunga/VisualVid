
Partial Class Controls_MostWatched
    Inherits System.Web.UI.UserControl

End Class
