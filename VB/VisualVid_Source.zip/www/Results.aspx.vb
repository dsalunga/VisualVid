
Partial Class Results
    Inherits System.Web.UI.Page

End Class
